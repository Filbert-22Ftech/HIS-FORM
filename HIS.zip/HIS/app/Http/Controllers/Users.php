<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\User;

class Users extends Controller
{
    //
    function dashboard()
    {
        return view('dashboard');
    }
    function create()
    {
        return view('create');
    }

    public function users(Request $request)
    {
        echo "<pre>";
        print_r($request->all());
    }


    public function loginsubmit(Request $req)
    {
        return User::select('*')->where(
            [
                ['email','=', $req->email],
                ['password','=', $req->password],
            ]
        )->get();
    }

}
